from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordRequestForm
from typing import Annotated

from schemas.schemas import Login, Token
from database.database import get_db
from models import models
from passwordhashing import PasswordManager
from jwttoken import create_access_token

router = APIRouter(prefix="/authentication", tags=["Authentication"])

db_dependency = Annotated[Session, Depends(get_db)]

@router.post("/login")
def login(login_details: Login, db: db_dependency):
    db_user = db.query(models.User).filter(models.User.email == login_details.email).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    db_user_password = db.query(models.UserPassword).filter(
        models.UserPassword.user_id == db_user.id,
        models.UserPassword.active == True
    ).first()
    
    if not db_user_password or not PasswordManager.verify_password(login_details.password, db_user_password.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    return {"message": "Login successful", "user_id": db_user.id, "username": db_user.username}

@router.post("/generate_token", response_model=Token)
def get_token(login_details: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    print(f"Login attempt for user: {login_details.username}")
    db_user = db.query(models.User).filter(models.User.email == login_details.username).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")
    
    db_user_password = db.query(models.UserPassword).filter(
        models.UserPassword.user_id == db_user.id,
        models.UserPassword.active == True
    ).first()
    
    if not db_user_password or not PasswordManager.verify_password(login_details.password, db_user_password.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    access_token = create_access_token(data={"sub": db_user.email})
    return {"access_token": access_token, "token_type": "bearer"}
