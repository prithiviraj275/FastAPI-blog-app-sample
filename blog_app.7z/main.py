from fastapi import FastAPI
from routers import user, blog,authentication
import models.models as models
from database.database import engine

app = FastAPI()
models.Base.metadata.create_all(bind=engine)

app.include_router(user.router)
app.include_router(blog.router)
app.include_router(authentication.router)


@app.get("/")
def index():
    return {"message": "Welcome to the FastAPI Blog App!"}
